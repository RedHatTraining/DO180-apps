#!/bin/bash
sudo podman build -t debug-httpd .
