#!/bin/bash

npm start
