#!/bin/bash

sudo podman build -t do180/mysql-57-rhel7 .
